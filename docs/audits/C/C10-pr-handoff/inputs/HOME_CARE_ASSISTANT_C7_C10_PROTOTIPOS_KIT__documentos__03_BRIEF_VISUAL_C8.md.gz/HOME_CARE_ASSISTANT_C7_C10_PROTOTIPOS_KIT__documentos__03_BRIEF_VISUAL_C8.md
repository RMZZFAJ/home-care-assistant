# C8 — Projeto visual e experiência humana, de tela em tela

## Referência a ser aprovada
`prototipo/home-care-prototipo.html` é um **protótipo navegável estático e demonstrativo**, produzido fora do repositório. Dados fictícios. Não contém backend, autenticação, assinatura, upload real, instalação PWA nem teste operacional. As interações simuladas não são contrato funcional. Não copiar JavaScript de simulação para produção.

**Estado atual: PROPOSTA VISUAL PARA REVISÃO DO RESPONSÁVEL.** Se aprovado, usar como direção geral de composição e linguagem. Não inferir aprovação sem manifestação expressa. O Codex não precisa recriar telas protótipo ou gastar tokens fazendo novos mockups; deve elaborar o projeto descritivo e mapear diferenças entre protótipo, AS_IS e C3. Mudanças visuais relevantes que contradigam a referência voltam à aprovação.

## Direção
- Fluent sóbrio, moderno, profissional e legível; tipografia do sistema, espaços bem definidos, superfícies claras, azul-petróleo atual como cor de marca, estados de negócio sem poluição.
- Desktop com navegação lateral, móveis com navegação compacta/atalhos; não duplicar componentes quando isso prejudicar acessibilidade.
- Conteúdo prioriza a tarefa do perfil. Status, próxima pessoa responsável e resultado real sempre explícitos.
- Formulários: rótulo visível, ajuda na tela quando contexto exige, botão/ícone de esclarecimento para regras mais complexas, exemplos, máscaras quando úteis, autocomplete legítimo, campo vazio ≠ zero, seletores buscáveis, avisos de estados.
- Padrões de feedback: skeleton com finalidade; atualizando com dado anterior identificado; vazio realmente consultado; erro/retentativa; resultado parcialmente salvo; resultado incerto; conflito; revogação com barreira de acesso e explicação persistente; sucesso específico.
- Padrões de decisão: 'antes → proposta → consequências → confirmar', sem modais desnecessários para filtros triviais.
- Permitir refazer profundamente uma tela problemática **se demonstrar ganho e preservar regras, migrações, permissões, autoria e acessibilidade**. Não obrigar remendos em estrutura ruim; também não reescrever tudo por preferência estética.

## Módulos do HTML
1. **Painel:** tarefas pendentes, métricas rotuladas, plantões, atalhos e hierarquia de urgência.
2. **REQ:** sequência curta com material, estoque observado vazio, desconhecido explícito, urgência e revisão.
3. **COM:** quantidade prevista x efetivamente validada, conclusão inferior e parcelas pendentes.
4. **ENT:** origem/destino, recebedora sugerida pela escala editável, aceite pessoal e divergência.
5. **BAL:** contagem física, diferença, revisão opcional e reconto por substituta com autoria separada.
6. **Escalas:** mês e dias, recorrência, horários padrão, prévia antes de publicar.
7. **Estoque:** saldos por custódia e trânsito, transferência simples, inativação com saldo.
8. **Profissionais:** identidade, função, vínculo e credencial declarada vs conferida.
9. **Histórico e PDFs:** cronologia, versão da ficha e emissão individual, verificador de exemplar assinado.
10. **Notificações e ciência:** tipos de comunicação, configurações e ciência separada de recebimento.
11. **Preparação de residência:** wizard com etapas e guia reaberto pelo perfil.
12. **Diálogos:** exemplos de decisão, rascunho, emissão, revogação, divergência, retomada e verificação.

## Entregáveis obrigatórios C8
**A. Inventário cruzado:** matriz de 97 superfícies B1 x 66 superfícies C3, com a origem AS_IS, destino TO_BE, status `PRESERVAR/ALTERAR/REFORMULAR/REMOVER_COM_JUSTIFICATIVA/NÃO_COBERTO`, perfil, referência ao protótipo quando existente; cada sobreposição/dependência; rótulo de evidência. Não somar números de critérios diferentes como se fossem mesmos denominadores.

**B. Especificação por tela:** ID estável; nome; perfil; dispositivo; endereço atual/futuro; objetivo; gatilho; layout desktop/mobile; componentes; acordeão/drawer/modal; campos com **tipo, ordem, máscara, obrigatório, default, dependências, ajuda, exemplo e erro**; ícones com texto alternativo; ações; estados (loading/empty/error/stale/offline/success/uncertain); foco/teclado/leitor de tela; passo anterior/próximo; permissão; impacto de validação; critérios C9; fontes A/B/C.

**C. Microcopy final e ajuda:** catálogo de cada botão, rótulo, tooltip, descrição, confirmação, mensagem de erro e recuperação, usando português humano; diferencia 'emitida' x 'recebida' x 'validada' x 'aprovada'. Se regra depende de P02, não inventar texto que confirme a política futura.

**D. Formulários:** mapa de campos, seleção por busca vs select simples vs checkbox vs número/decimal, máscaras e controle de valores; reaproveitar itens/atalhos listáveis sem converter contagem antiga em atual.

**E. Tutoriais:** matriz `perfil × tarefa × guia contextual × passo × screenshot real futuro`, incluindo guia de primeiro acesso controlável no cadastro e reaberto no perfil. Capturas de protótipo são referências, não evidências do sistema atual.

**F. Padrões responsivos:** desktop, tablet Android, Android phone, iPhone, navegadores relevantes e PWA; aprovar com teste real na D, sem declarar homologação.

**G. Regras anti-retrabalho:** não criar protótipos adicionais só para preencher auditoria; variações adicionais devem ter motivo e valor decisório; divergência do HTML aprovada pelo responsável antes de alterar código.

## Exemplos visuais a observar
- O dashboard não mostra tarefas técnicas às profissionais; perfis terão conteúdo próprio, não apenas escondem botões visualmente.
- ENT exibe recebedor real e nunca opção de 'confirmar por terceiro'.
- BAL revisão opcional; diferença não vira débito automático.
- Documento no histórico tem versão e **emissão** distintas.
- Rascunho de REQ não aparece ao abrir BAL, e descarte jamais apaga ficha emitida.
- Disponibilidade PWA/push depende de navegador e instalação; manter tarefas visíveis mesmo sem push.
