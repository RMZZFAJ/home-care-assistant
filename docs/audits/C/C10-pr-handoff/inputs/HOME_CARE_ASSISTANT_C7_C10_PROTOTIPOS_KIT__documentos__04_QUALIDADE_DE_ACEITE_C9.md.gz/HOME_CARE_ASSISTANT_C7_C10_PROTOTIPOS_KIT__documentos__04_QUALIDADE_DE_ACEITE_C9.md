# C9 — Revisão semântica, critérios de aceitação e oráculos discriminantes

## Escopo
Revisar as 121 causas consolidadas, os 165 registros originais, as 28 capacidades/decisões aprovadas, os 149 critérios existentes e os requisitos complementares deste pacote. **É uma revisão do PLANEJAMENTO, não execução da D.** Não criar testes que acessem banco remoto, não corrigir produto nem suprimir cenários de falha.

## Auditoria semântica obrigatória de ponta a ponta
Para cada causa e critério, confrontar **o texto original do achado e sua evidência** com: `cause_id`, processo real, regra afetada, decisões humanas pertinentes, spec C3, impacto C4, lote D0–D7, resultado esperado, prova, prioridade, dependência e `feature gate`. Não aceitar automaticamente relações porque IDs aparecem preenchidos.

**Caso de atenção identificado previamente:** `C-CAUSE-001` originada em `DB-006` refere lote de lembretes por configuração sem progresso; a matriz C4 a associa a REQ e decisões sobre estoque observado. Investigar tecnicamente se a associação está correta ou se deveria apontar principalmente para scheduler/worker/BAL/notificações; corrigir apenas conforme evidência, preservando diferenciação de `C-CAUSE-049`/`DB-002` sobre lifecycle REQ. Validar TODAS as demais linhas, não só esse exemplo.

## Formato mínimo de cada caso de aceitação
`ACCEPTANCE_ID; CAUSE/DECISION; RISK; PRECONDITION; ACTOR; TEST_DATA; ACTION_STEPS; EXPECTED; FORBIDDEN; INDEPENDENT_ORACLE; SIDE_EFFECTS; AUTH; UI_STATES; PDF/EVENT; FAILURE_RECOVERY; LAYER; FIXTURE; AUTOMATION_PLAN; HUMAN_DEVICE_PROVIDER_REQUIREMENT; SOURCE; LOT; RELEASE_GATE; DECISION_DEPENDENCY; STATUS`.

**Mínimos de qualidade:**
- `EXPECTED` e `FORBIDDEN` não podem ser frases genéricas como “comportamento correto”; descrever o comportamento observável em números e estados.
- `PRECONDITION` e `TEST_DATA` especificam amostras fictícias, valores zero/NULL/ausente, contagem, papel e paciente quando pertinentes.
- `INDEPENDENT_ORACLE` deve conferir read-back, evento/versão/ator, ledger ou bytes efetivos; API 200 isolada não basta.
- Diferenciar `NOT_TESTABLE_BEFORE_IMPLEMENTATION` de `DESIGN_READY`, `BLOCKED_BY_OWNER_DECISION`, `NEEDS_REAL_HARDWARE`, `EXTERNAL_PROVIDER_REQUIRED` e `PLANNED_D`.
- Consolidação pode unir execuções, mas não perder os critérios de cada causa. Não executar todos agora.

## Exemplos de cenários exigidos
### ENT indelegável
Destinatária designada Sheila, entrada expedida; Juliana com vínculo ativo tenta aceitar. Esperado: negado; nenhum `received_by=Juliana`, nenhum crédito de equipe indevido; Sheila aceita pelo próprio vínculo e o histórico registra autoria adequada. Caso revogado deve falhar; concorrência não duplica.

### BAL revisão opcional
Profissional conclui contagem; sem revisão iniciada, BAL pode estar legitimamente registrado sem indicar pendência universal. Se família pede reconto, nova tarefa atribuída a Sheila conserva autora original Juliana. Diferença sem confirmação não vira consumo/ajuste.

### P02 ciência
Para cada SCI-ID aprovado: testar modalidade permitida/proibida, modo anterior, usuário desvinculado, reabertura, mudanças de preferência, acesso distinto de ciência, ciência tácita que não prova leitura. Enquanto não houver tabela aprovada, status `BLOCKED_BY_OWNER_DECISION`.

### Rascunho
Iniciar REQ, salvar servidor, reabrir outro dispositivo e escolher continuar/descartar; iniciar BAL não mostra REQ; descartar REQ não remove ENT oficial nem gera PDF, ledger ou evento oficial. Conflito entre dois dispositivos não sobrescreve silenciosamente.

### Assinatura de PDF
Gerar mesmo documento/versão em dois momentos → duas emissões identificáveis; baixar de novo a mesma emissão → bytes iguais; adulterar exemplar → validação de assinatura/hash falha; alterar conteúdo operacional → versão correta identificada. Verificar datas, autor técnico do certificado, agente que solicitou, fuso; não incluir IP no QR e não chamar assinatura pessoal. Testar leitor PDF e cadeia de certificado reais no D.

### Transferência e devolução
Equipe devolve 5 fraldas → baixa origem/transita/crédito após aceite físico correto; família solicita retorno → diferenciar declaração e aceite; ajustar saldo sem fato físico não deve simular transferência; compra validada e consumo mantêm seus contratos próprios.

### Falha/revogação
Usuário inicia confirmação, vínculo é revogado antes do commit → negar escrita, status correto, informar impacto e destino seguro; se resposta foi perdida após commit válido, não afirmar “ação não registrada” sem consultar resultado.

### Teste negativo do teste (oráculo)
PDF com texto omitido reprova verificação de conteúdo; saldo esperado positivo mas read-back NULL reprova; falha do axe automatizado e resultado inconclusivo não viram conformidade; CI só vale para SHA candidato.

## Entrega para D
Gerar cenários **descritivos completos** e backlog de instrumentação de testes por lote, agrupados por dependências. Não gerar centenas de testes temporários antes da alteração funcional. Cada pacote D detalhará casos em código, fixtures e evidências após autorização.
