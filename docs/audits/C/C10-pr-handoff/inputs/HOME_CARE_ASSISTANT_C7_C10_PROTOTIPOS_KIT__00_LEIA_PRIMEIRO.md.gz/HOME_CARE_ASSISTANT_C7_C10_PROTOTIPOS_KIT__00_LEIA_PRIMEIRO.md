# Home Care Assistant — Fechamento C7–C10 e protótipos visuais

**Produzido em 04/11/2026.** Pacote externo ao repositório, para revisão do responsável. Nenhum commit, PR, merge, deploy ou alteração de dados reais foi executado pela criação deste pacote.

## 1. O que abrir primeiro

`prototipo/home-care-prototipo.html`: abrir no navegador. É um **protótipo visual navegável**, com dados fictícios. Possui painel, requisição, aquisição, entrega, balanço, escala, estoque, profissionais, histórico, notificações/ciência, onboarding e diálogos ilustrativos. A navegação e os diálogos funcionam localmente; formulários, assinatura, push e gravação são demonstrações, não implementações.

Capturas de referência na pasta `prototipo/` auxiliam a revisão. A interface é responsiva; testar reduzindo a janela ou acessando o HTML pelo aparelho quando possível.

## 2. O que aprovar

Aprovar, rejeitar ou corrigir a **direção visual**, não cada demonstração de dado: hierarquia, densidade, organização, botões, rótulos, estados, painéis, uso em celular e estilo dos formulários. Se desejar, responder por módulo (`painel`, `req`, `com`, `ent`, `bal`, `schedule`, `stock`, `staff`, `docs`, `notify`, `setup`).

**A aprovação do protótipo é necessária antes de tratá-lo como orientação visual definitiva ao Codex.** O Codex poderá produzir o blueprint descritivo sem refazer mockups e registrará a aprovação quando ela existir.

## 3. Arquivos-base

- `documentos/01_DECISOES_APROVADAS_E_LIMITES.md` — todas as decisões recentes e as ressalvas de privacidade/integridade.
- `documentos/02_INVENTARIO_DE_CIENCIAS_E_ATOS.md` — ordem para inventário completo dos tipos de ciência antes da escolha individual P02.
- `documentos/03_BRIEF_VISUAL_C8.md` — escopo do detalhamento visual tela por tela.
- `documentos/04_QUALIDADE_DE_ACEITE_C9.md` — critérios e revisão semântica de causas/aceites.
- `documentos/05_POLITICA_PR_CI_BRANCHES.md` — draft PR, checks, revisão, merge futuro e limpeza segura.
- `documentos/06_ORDEM_MESTRA_FASE_C_PARTE_2.md` — ordem integral C7–C10 para Codex.
- `documentos/07_COMANDO_INTERPOSICAO_CODEX.md` — comando principal curto para enviar.

## 4. Procedimento sugerido

1. O responsável abre o HTML e aprova/ajusta a direção visual. Não há necessidade de o Codex criar telas temporárias.
2. Depositar os arquivos Markdown e HTML na raiz ou pasta de entrada do repositório **apenas quando autorizado**; o Codex poderá movê-los e consolidá-los sob `docs/audits/C`.
3. Abrir conversa Codex com **Ordem Mestre** anexada como texto e **Comando de Interposição** como mensagem principal. Incluir os demais arquivos-base, especialmente o HTML.
4. O Codex executa C7–C10 documentalmente, produz inventário de ciências **P02** para votação por tipo, reconciliação semântica, blueprint visual, aceites precisos e draft PR.
5. **Não fazer merge na primeira execução**. O responsável poderá discutir P02, revisar o PR e aguardar CI. Depois chamará o Codex para mudanças/revisão e eventual merge com checks do mesmo SHA.
6. Só após merge verificado é que a branch D será criada da `master` atualizada. Branches antigas integradas poderão ser eliminadas com inventário, sem destruir histórico útil.

## 5. Atenções

- Rascunho descartado não vira documento oficial, mas nenhuma exclusão pode apagar fato registrado ou evidência sujeita a preservação.
- Cada emissão nova de PDF assinado é um exemplar individual; baixar o mesmo exemplar não é o mesmo que emitir outro.
- No PDF público, privilegiar metadados mínimos; IP e informações de máquina não devem ser publicados automaticamente.
- Uma confirmação pessoal de recebimento não pode ser delegada; revisão BAL é facultativa na política decidida.
- Proposta visual, especificação futura e funcionalidade implementada são coisas diferentes.
