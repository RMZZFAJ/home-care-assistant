# C10 — Política de PR, CI, preservação histórica e branches

## Estado de partida (verificar novamente antes de executar)
Em 04/11/2026, `audit/phase-b` apontava para `992c6303e9da158073f2e3e75957d0faa49fa4ee`, `master` para `34dcb835c5c49068e0417f7306eb4e501aa868bc`; 18 commits à frente sem divergir, nenhum PR aberto. **Não presumir que esses SHAs continuam válidos**. A comparação independente encontrou diferenças fora de `docs` em `.gitignore`, `.vscode/settings.json` e `requirements-audit.txt`, sem diferença em `src/`, `supabase/`, `tests/` e workflows entre aquelas referências.

## Antes de abrir draft PR
1. Confirmar `git status`, branch e ancestry; não misturar mudanças não autorizadas, nem apagar worktree do usuário.
2. Revisar escopo diferencial da branch contra `master`, incluindo arquivos movidos, anexos, nomes, macros e arquivos binários. Verificar tamanho e limites do PR.
3. Reexecutar somente validações documentais apropriadas, mapas de relocação, Markdown, referências, integridade das evidências e confidencialidade. **Não transformar PR de documentos em teste de carga ou reset remoto.**
4. `docs/current` continua AS_IS; `docs/decisions` são regras aprovadas; `docs/audits/C` é TO_BE; fase D ainda não iniciada. Atualizar links e status sem inventar implementação.
5. Preservar `docs/audits/A`, `B/B1..B8`, `C/C0..C10` e início vazio D. Achados e hashes antigos devem continuar recuperáveis, sem reescrever prova.
6. Verificar configurações de Vercel e proteção de produção: **merge em master pode disparar deploy**, mesmo que PR seja apenas documentação. Se não houver separação ou bloqueio que preserve a operação, pedir autorização e recomendar configuração de proteção antes do merge.

## Criação do draft
- Criar PR de **`audit/phase-b` → `master`** com título semelhante `docs(audit): encerra A–C e prepara Fase D`.
- **Estado DRAFT**; incluir resumo humano, escopo, lista de verificações, limitações, 165 achados/121 causas (sujeitos à reconciliação C7), 149 aceites refinados, decisões e P02 ainda abertas, referências aos protótipos e matriz visual, demonstração de integridade e diff não funcional.
- Não incluir IDs, credenciais, dados reais, IPs, backups privados ou instruções de envio externo.
- Abrir draft inicia CI quando workflow `on: pull_request` estiver ativo. **Não aguardar o término inteiro em execução que consuma tempo e recursos**: registrar link do PR, SHA e verificações pendentes; encerrar e aguardar nova solicitação do usuário. Não declarar CI verde sem consultá-la.
- Se o responsável ou outra IA trouxer revisão, aplicar no mesmo PR com novo commit, invalidando checks anteriores; CI final precisa corresponder ao novo HEAD.

## Autoridade de merge
**Não realizar merge nesta execução**, mesmo se CI passar; o responsável disse que chamará o Codex depois da revisão e dos resultados de CI. Só efetuar merge em missão posterior com autorização expressa vigente, revisão aprovada, checks obrigatórios verdes para SHA correto, ausência de conflito e verificação do efeito de Vercel sobre `master`.

## Histórico e estratégia de merge
Para histórico forense de auditorias, preferir **MERGE COMMIT**: conserva os SHAs individuais na ancestralidade da `master`. `SQUASH` não conserva cada commit da branch como ancestral individual; PR não substitui tag ou histórico alcançável quando branch é apagada. A estratégia final depende de permissões/políticas do repositório. Pode criar tag de referência de auditoria com autorização adequada.

## Limpeza de branches
Somente **após merge verificado**:
- Listar **todas** as branches locais e remotas com SHA, proteção, PR associado, merge status e trabalho não integrado.
- Excluir apenas branches obsoletas **efetivamente integradas** e não protegidas, individualmente e com justificativa. Não apagar branch ativa do PR, branch com PR aberto, branch D recém-criada, branch protegida ou qualquer branch não integrada. Não usar `push --delete` em lote cego ou `git branch -D` como solução padrão.
- Manter `master` e, na fase seguinte, uma branch D baseada em `master` já atualizada. A preferência do responsável por poucas branches é respeitada sem perder trabalho.
- Se GitHub estiver configurado, habilitar apenas com autorização `Automatically delete head branches`, para branches de PR mescladas (não substitui verificação de segurança). 

## Vercel e Supabase
- Atualização de `master` pode desencadear build/deploy conforme integração; antecipar efeitos antes do merge.
- Não mudar schema/dados/segredos remotos na C7–C10.
- Projeto operacional futuro será separado, limpo, e só criado quando a D6 autorizar.
