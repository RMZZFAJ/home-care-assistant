# Ordem de inventário de ciências, acessos, aceites e declarações — pré-condição P02

**P02 não está aprovada tipo por tipo. Não inferir configurações.** A C7 deve entregar esta lista a quem decide, com indicação dos tipos realmente existentes, distinguindo os atos mencionados em documentação daquilo que o código permite executar hoje.

## Objetivo
Enumerar **cada tipo real de ciência** do Home Care Assistant e classificar eventos próximos que não são ciência. Responder: de qual documento/estado nasce, quem precisa declarar, quando, efeito, se é manual/ao abrir/tácita elegível, se é obrigação de decisão ou ato físico, acesso exigido, prova no banco, histórico e interface. **Não confundir registro de acesso, notificação entregue, leitura, ciência, aceite físico, aprovação, conferência, revisão e assinatura.**

## Fontes de análise que o Codex deve cruzar
1. Registros de `docs/current`, `docs/audits/A`, `docs/audits/B/B1..B8`, `docs/decisions`, `docs/audits/C/C3-functional-specification` e inventários de mensagens.
2. Código executável: tabelas/routines `supabase/migrations`, enums, eventos de documentos, tipos TypeScript, validação, APIs `src/app/api`, componentes REQ/COM/ENT/BAL, auditoria de acesso e preferências.
3. Casos distintos para paciente, papel, ação, motivo, mudança de estado e consentimento. Verificar se ciência é explícita ou tácita **hoje** e o que seria **futuro**.
4. Regras de auditoria: acesso efetivo é fato independente; não registrar 'leu' sem leitura demonstrada.

## Tabela obrigatória para deliberação
`ID | Área | Nome exibido | Fato que dispara | Documento/versão | Obrigado a dar ciência | Ator autorizado | Comportamento AS_IS | Evidência | Manual? | Diálogo ao abrir? | Tácita? | Não configurável? | Risco/impacto | Recomendação | Decisão responsável | Status`.

Entregar lista completa em Markdown compreensível e CSV estruturado. Itens sem evidência devem ser marcados **NÃO COMPROVADO**; não inventar a lista definitiva. Cada linha terá espaço para aprovação do responsável.

## Regra preliminar de classificação (não é aprovação final)
- **Candidatos a ciência configurável:** ciência informativa de REQ/documento/aviso, quando o contrato permitir; sujeito à aprovação por tipo.
- **Não configurar como tácita:** recebimento físico ENT, contagem BAL, revisão ou aprovação de BAL, decisão de compra, aprovação de troca de plantão, aprovação administrativa, transferência física, manifestação de divergência, ciência que constitua requisito legal de forma/aceite pessoal, assinatura e envio de documento.
- **Não é ciência:** abrir documento (`document_opened`), visualizar parte da tela, push enviado/entregue, notificação lida, arquivo baixado, criação de rascunho. Podem ter auditoria própria.

## Formato da revisão humana
O responsável deve poder responder no estilo: `SCI-001: manual e ao abrir, nunca tácita; SCI-002: as três; SCI-003: sempre expressa`. Depois disso registrar a política com `OWNER_APPROVED`, data e vínculo com C3/C4/C9. **Não habilitar ciência tácita antes de classificar cada caso.**

## Particularidades técnicas a impedir
- Não disparar ciência toda vez que ficha for reaberta após já ter ciência válida; manter registro de acesso de cada abertura autorizada, com moderação de ruído/batch de auditoria devidamente especificado.
- Não presumir ciência em data de emissão para usuário que não estava elegível no momento.
- Não permitir preferência tácita sobrescrever exigência maior do processo.
- Não atribuir ciência ao usuário revogado, sem vínculo ou sem ter configurado a preferência.
- Mudança de preferência vale prospectivamente e deixa trilha mínima; não muda ciência histórica.
- A prova deve distinguir `registrada automaticamente conforme preferência` de `confirmada manualmente pelo usuário`.

**Bloqueio:** C7 pode encerrar o inventário; a escolha linha a linha não pode ser declarada concluída enquanto o responsável não aprovar. A C8/C9/C10 poderão prosseguir no que independer disso. PR pode ficar draft aguardando resposta; não fazer merge com política indefinida anunciada como aprovada.
