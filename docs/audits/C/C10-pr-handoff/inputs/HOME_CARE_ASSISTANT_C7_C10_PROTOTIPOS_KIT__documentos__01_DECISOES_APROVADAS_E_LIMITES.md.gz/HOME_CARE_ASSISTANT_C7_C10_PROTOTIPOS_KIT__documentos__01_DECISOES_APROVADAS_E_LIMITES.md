# Registro complementar de decisões — C7–C10

**Estado:** instruções de produto do responsável; base para reconciliação documental. **Não descreve funcionalidades já implementadas.**

**Fonte primária:** decisões fornecidas pelo responsável nesta conversa após o fechamento da Fase C, complementadas por `docs/decisions/PRODUCT_DECISIONS_MASTER.md` e `docs/audits/C/C2-decisions/HUMAN_DECISIONS_REVIEW.md`. Quando houver divergência, explicitar a regra mais recente e preservar histórico do que mudou. Não inventar aprovação de pontos não respondidos.

## P01 — Identidade e credenciais: aprovado
- O administrador da família confere dados e credenciais de profissionais quando aplicáveis, registrando autor, data e resultado. Nome individual, função, conta própria, vínculo e registro obrigatório conforme profissão; cuidadores sem registro profissional aplicável não são obrigados a fornecer COREN.
- Distinguir **informado**, **conferido por responsável** e **validado por fonte externa**; não confundir os três.
- Evolução futura: upload protegido de documento profissional e consulta de validação externa. Não implementar automaticamente nesta entrega.

## P02 — Ciência: **aguarda inventário completo dos atos do sistema e decisão individual do responsável**
- O objetivo aprovado é permitir configuração por **tipo de ciência elegível** entre: manual; confirmada por diálogo na primeira abertura; tácita conforme preferência/consentimento prévio.
- Registrar acesso efetivo a documento separadamente da ciência.
- Ciência tácita não significa leitura; confirmação ao abrir antes da exibição tampouco comprova leitura integral.
- Recebimento ENT, revisão/aprovação, contagem física, aceite, assinatura pessoal e decisões materiais **não são** meras ciências e nunca podem ser satisfeitos por preferência tácita.
- **Bloqueio decisório:** inventariar no código banco, eventos, APIs, telas, notificações e políticas os tipos reais de ciências, leituras, visualizações e aceites; produzir tabela enumerada com evidências e proposta de modalidades admissíveis. Submeter ao responsável para decisão tipo por tipo. Não escolher silenciosamente.

## P03 — Backup: direção aprovada; parâmetros econômicos ainda para decisão
- Proteção intermediária aprovada. Cobrir banco, Auth, Storage, versões documentais assinadas, configuração, jobs e recuperação sem reenvios/reexecuções indevidas.
- Estudar **custo total e esforço do proprietário**: serviços atuais, capacidade nativa, ferramentas gerenciadas, automação, notificações, destino seguro, frequência de checagem, tarefas manuais por dia/mês, responsabilidade em falha, processo de restore em quarentena.
- Metas **propostas, não contratadas** de RPO 1h e RTO 4h: avaliar viabilidade/custos, apresentar alternativas mais econômicas e não anunciar garantia inexistente. Preços sempre com fonte/data se pesquisados; não inventar preços e não contratar ferramentas.

## P04 — Produção: aprovado
- Criar ambiente operacional real **separado e limpo** após correções e homologação, em Vercel/Supabase e demais sistemas necessários, sem transportar fixtures nem registros fictícios. Nenhuma criação/contratação autorizada agora.

## P05 — Contingência: aprovado com documento posterior
- Responsável principal é administração familiar; casos críticos admitem segunda conferência conforme ato; suporte global trata infraestrutura. Preservar distinção entre conciliação e confirmação física.
- Ao fim de regularização excepcional, gerar PDF completo: protocolo, paciente/unidade quando autorizado, fato/pendência, estado anterior, motivo excepcional, medidas, base de autorização, quem propôs, decidiu e executou, horários, movimentos, referências, efeitos, ressalvas e resultado final; exemplar assinado/verificável quando sistema estiver homologado.
- Notificar envolvidos de forma proporcional, inclusive pessoa desligada **quando houver base legítima e canal seguro**, sem restaurar credenciais nem divulgar dados de terceiros. Comprovar tentativa de notificação não é comprovar leitura/recebimento.

## P06 — Recebedor fora da escala: aprovado
- Sugerir pessoa na escala; família pode escolher manualmente profissional vinculado/elegível, registrando exceção. Somente quem **recebeu fisicamente** confirma a ENT, pessoalmente, sem delegação.
- Se não houver pessoa elegível, preservar pendência/contingência, não fabricar aceite.

## P07 — Transferência simplificada: aprovado **com análise de unificação condicionada**
- Interface simplificada usando preferencialmente motor de ENT/custódia com origem, destino, quantidade, motivo padronizado, observação, usuário, contraparte e vínculo opcional a REQ/ENT/BAL/outro documento.
- Mapear todas as movimentações existentes **antes** de substituir a função de devolução: devolução física pode ser um tipo de transferência; compra validada, consumo, saldo inicial e correção de estoque são fatos distintos e não devem virar falsa transferência.
- Definir regras por tipo: confirmação da contraparte e aceite do recebedor pessoal quando atos diferentes; quando/por quem pode ocorrer ajuste de saldo (inclusive se depende de BAL), justificativa, prova, vinculação à origem e autorização; nenhuma movimentação fictícia para ajustar número.
- Só propor remover UI antiga de devolução após matriz **AS_IS → TO_BE**, cobertura completa e regressões.

## P08 — Retenção e rascunhos: decisão de produto com limites de integridade
- Retenção conservadora por categoria e finalidade, observando normas aplicáveis, privacidade, obrigações de conservação e eventual preservação por disputa.
- **Rascunho não é ficha oficial**: nenhum protocolo definitivo, documento emitido, crédito/débito, ciência, versão de documento oficial ou evento de ledger por simples autosave.
- Um rascunho transitório, privado e recuperável pode ser persistido no servidor para continuidade entre dias/aparelhos. Evitar que apareça como documento oficial, como pendência para terceiros ou em PDF.
- Descartar rascunho não permite apagar ato já concluído, registro oficial, evento de segurança que deva ser mantido, backup sujeito à retenção ou material em preservação legal. Não prometer inexistência absoluta de vestígios de acesso/autosave; definir retenção técnica mínima e acesso restrito.

## P09 — PDF: **opção B aprovada como mínimo obrigatório**
- Exigir assinatura criptográfica **do sistema** incorporada ao PDF final, com verificação válida no formato/interoperabilidade definidos (avaliar PAdES e leitores usuais), proteção das chaves, certificado, identidade do signatário técnico, cadeia de confiança e ciclo de renovação/revogação. Apresentar custos/alternativas de certificado, chaves e carimbo de tempo antes da contratação.
- Cada **emissão** possui ID, data/hora, quem solicitou e contexto próprio; duas emissões do mesmo conteúdo/versão podem gerar PDFs assinados distintos. Separar `versão da ficha`, `identificador da emissão`, `hash do conteúdo de negócio` e `hash dos bytes finais assinados`.
- Incluir em rodapé/QR (de forma não sensível): protocolo, versão, número da emissão, instante/fuso, agente que solicitou emissão segundo autorização e URL/código opaco para verificação. Assinatura representa o **sistema**, não assinatura pessoal desse agente.
- Capturar quando necessário em **trilha interna protegida** ambiente, origem funcional, contexto do cliente, IP e metadados mínimos. IP não é geolocalização confiável; não inserir IP, identificação de máquina, localização precisa ou dados pessoais sensíveis no PDF/QR por padrão. GPS exige justificativa/necessidade e autorização específicas.
- Ordenar operação: compor PDF+QR+metadados não sensíveis → assinar → persistir bytes finais imutáveis + hash+referência → verificar. Não editar o PDF após assinado; conferir eventuais anotações, versão, renderização e testes de alteração externa.

## P10 — Homologação: aprovado
- Notebook, tablet Android, celular Android e iPhone; navegadores nativos e alternativos relevantes (ex.: Chrome). Testar a experiência de instalar PWA e push em aparelhos reais. No iPhone, push de web app tem condições específicas de instalação/permissão; não prometer equivalência irrestrita com abas do navegador. Pessoas reais da família e equipe, impressão e acessibilidade aplicável; modelos/versões no D6.

## P11 — Supervisão e leitura: decisão revista
- BAL **não exige revisão em todos os casos**. A contagem do profissional é registrada; família/supervisão *podem* revisar, solicitar esclarecimento/reconto ou registrar decisão quando adequado.
- Não classificar todos os BAL como pendentes de revisão obrigatória. Se uma revisão for iniciada, seus atos e autoria devem ser preservados. Respeitar eventual situação excepcional em que outro procedimento legal/contratual exija decisão específica, sem transformar em política universal.
- Perfis exclusivos de supervisão/leitura podem ser ativados posteriormente, preservando as capacidades necessárias à família e equipe no primeiro uso.

## P12 — Rascunhos: aprovado, substitui sugestão de 90/180 dias
- Rascunho por **usuário + paciente + tipo de processo** (e contexto da intenção quando aplicável), disponível em outro aparelho e dia. Inicialmente no máximo um rascunho de criação por tipo; para aprovações/divergências vinculadas a documentos diferentes, usar chaves por intenção para evitar perda cruzada.
- Ao iniciar nova ficha do *mesmo* tipo, mostrar conteúdo básico, data, hora, itens, estado de salvamento e opções **Continuar** ou **Descartar e começar nova**. Somente após confirmação descartar o anterior. Iniciar REQ não evoca BAL, nem vice-versa.
- Descarte é de rascunho, jamais de documento oficial. Evitar lista interminável de rascunhos. Política de TTL puramente técnica para exceções poderá ser proposta, mas não aplicar eliminação automática sem aprovação.
- Registro de auditoria oficial só começa no ato oficial definido; logs técnicos mínimos não são o mesmo que ficha oficial.

## P13 — Alertas: aprovado
- Falhas de backup, integridade, infraestrutura, worker, segredos ou serviço externo somente em canais do administrador global/suporte habilitado, com grau de gravidade proporcional. Equipe vê apenas impacto na tarefa, instrução humana e canal de suporte, sem informações internas confidenciais.
- Padrões de alertas futuros podem ser configuráveis granularmente, sem criar complexidade inicial. A mensagem não revela dado de outro paciente.

## P14 — COM inferior: aprovado
- Concluir com quantidade inferior somente depois de validar parcelas físicas pertinentes e confirmar desistência do restante; quando há parcelas aguardando validação, encerrar só a expectativa de novas aquisições, mantendo conferência pendente com status honesto. Nunca creditar quantidade não recebida.

## P15 — Revogação: aprovado
- Revalidar autorização antes de concluir ato crítico; revogação impede nova escrita. Se revogado durante operação, apresentar mensagem clara de que **a ação não foi registrada**, com motivo inteligível e orientação; limpar dados protegidos ao sair do contexto.
- Projetar estado/modal/barreira de acesso persistente e outra mensagem contextual para ação negada, sem sumir imediatamente ao redirecionar; oferecer retorno seguro e ajuda, sem navegação a conteúdo não autorizado nem loop de mensagens.
- O texto deve dizer “não concluída” somente quando a operação de fato foi comprovadamente não persistida; em resultado incerto, consultar o estado oficial antes de afirmar ausência de registro.

## O01 — Guia do primeiro acesso: aprovado
- Ao cadastrar ou vincular usuário, administrador global/local define `mostrar guia no primeiro acesso` conforme autoridade. O usuário pode reabrir a apresentação guiada a qualquer tempo pelo perfil. Conteúdo contextual por perfil; incluir ajuda com capturas de exemplo quando aplicativo real estiver pronto.

## O10 — Reaproveitamento e reemissão: diretriz
- Dados oficiais não mudam por novo download; cada PDF **reemissão** identifica evento próprio, agente, hora e contexto. Histórico do documento e histórico das emissões são relacionados, mas diferentes. Não reutilizar PDF assinado anterior como se fosse exemplar recém-emitido se o usuário escolheu nova emissão.
- Diferenciar **baixar novamente mesmo exemplar** (bytes idênticos/hashes iguais) de **emitir novo exemplar** (novo ID/assinatura/hashes potencialmente distintos); mostrar ações distintas na interface.

## O01+ — Painel de preparação de paciente: aprovado
- Wizard próprio para criação/configuração de nova residência/paciente, inicialmente autorizado somente ao administrador global. Vincular paciente, administradores familiares, equipe, catálogo, saldos iniciais, escalas, regras de BAL, documentos, preferências, canais e contingência; não confundir setup completo com ambiente homologado.
- Futuramente avaliar empresa/supervisão como criador, sem conceder essa permissão agora.

## VISUAL — V01–V10 aprovados como direção
- Fluent profissional, moderno, sóbrio; identidade visual base preservada, sem reformulação radical obrigatória.
- Permitir **reconstrução de tela/fluxo** onde uma correção localizada custaria mais ou perpetuaria complexidade; respeitar contratos, permissões, eventos, acessibilidade e funcionalidades.
- Especificar individualmente cada tela, diálogo, componente, texto/ícone, campo, máscara, lista, preenchimento automático, ajuda inline e contextual, tutorial e estados de espera/erro/conflito/sucesso/mobile.
- **Protótipos visuais serão produzidos fora do Codex, revisados pelo responsável antes de virarem direção vinculante.** Arquivo fornecido é referência de layout, nunca código de produção e nunca substitui testes.

## PR E BRANCHES — autorização condicional
- Preparar **draft PR** após C7–C10, sem esperar no mesmo turno por toda a CI; abrir PR dispara as verificações cabíveis. Se receber comentários externos, usuário chamará o Codex depois.
- Só fazer merge após CI obrigatória aprovada para **o mesmo SHA** e após aprovação explícita do responsável naquele momento; considerar Vercel, pois merge em `master` pode disparar implantação automática, mesmo sendo PR documental.
- Após merge, pode eliminar **branches remotas antigas efetivamente integradas**, preservando histórico alcançável em `master`, PRs, hashes e preferencialmente referência/tag imutável da auditoria. Preferir merge commit para preservar a sequência da auditoria; não remover branch com trabalho não integrado, branch protegida ou branch ativa da futura D. Não efetuar limpeza genérica apenas pelo nome.
- Criar branch D a partir da `master` atualizada, em missão posterior. **Nenhuma alteração funcional está autorizada pela C7–C10.**
