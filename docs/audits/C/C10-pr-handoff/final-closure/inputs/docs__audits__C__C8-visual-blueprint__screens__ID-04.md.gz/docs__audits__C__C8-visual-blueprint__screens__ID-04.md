# ID-04 — Gerir profissionais e vínculos

Estado: direção visual OWNER_APPROVED; especificação TO_BE, não implementada.

Perfil e permissão: Admin local de A, global no seu contexto. Banco/API
revalidam capacidade, alvo e versão; menu/ID/escala não concedem autorização.

Rota/superfície: /admin vínculo/convite, atual a alterar. Gatilho: navegar
pela tarefa ou abrir o alvo contextual autorizado. Objetivo: Convidar, editar
vínculo da pessoa, revogar e inventariar tarefas.

## Composição e sequência

Lista de pessoas/vínculos e estado da credencial; drawer alvo fixo; diálogo
próprio de revogação.

Desktop: aplicar essa hierarquia no shell aprovado, tarefa primeiro e ajuda
lateral quando útil. Tablet: preservar ordem de foco e duas colunas só se
rótulos/valores couberem. Móvel: empilhar na mesma ordem; diálogo longo ocupa
largura disponível e rola internamente, footer não cobre campo/teclado;
resumo/ações continuam alcançáveis.

Trocar pessoa é outra intenção; cuidadora sem registro aplicável não precisa
COREN.

## Ações e efeito

Primária: **Salvar vínculo da pessoa**. Secundárias: Convidar; Revogar agora;
Ver tarefas; Conferir credencial.

Consequência: Vínculo local não edita identidade global de terceiro. Mostrar
objeto/quantidade/pessoa/versão antes de qualquer decisão material.
Retorno/Voltar preserva edição e contexto; próximo destino é resultado do ato
ou tarefa pertinente, nunca novo envio automático. Em resposta incerta
consultar intenção antes de prosseguir.

## Controles em ordem de tarefa

Os IDs abaixo são canônicos no catálogo de controles. Campos compostos C3
foram desdobrados; na revisão/detalhe aparecem em leitura, não novamente
editáveis. Servidor é a origem de identidade/versões/estados.

- **CTRL-105-01 — E-mail de acesso**. EMAIL_INPUT. Ordem 105.1; Sim no
  login/convite. Máscara/autocomplete: Formato e-mail; sem autocapitalização;
  email. Dependência/validação: Formato, até 254; confirmação pelo Auth para
  aceite. Ajuda/exemplo: “<pessoa.exemplo@dominio.test>”, fictício.. Erro:
  Revise e-mail de acesso: Formato, até 254; confirmação pelo Auth para
  aceite..

- **CTRL-113-01 — Papel**. SEARCHABLE_COMBOBOX. Ordem 113.1; Sim ao
  convidar/editar. Máscara/autocomplete: Busca por nome/alias autorizado;
  seleção por ID; nenhum ID digitado como autorização; off.
  Dependência/validação: Pessoa-alvo fixa em edição; trocar pessoa é outra
  ação explícita. Ajuda/exemplo: “Editar o vínculo de Ana”, sem substituir
  Bruno silenciosamente.. Erro: Revise papel: Pessoa-alvo fixa em edição;
  trocar pessoa é outra ação explícita..

- **CTRL-113-02 — Estado do vínculo**. SEARCHABLE_COMBOBOX. Ordem 113.2; Sim
  ao convidar/editar. Máscara/autocomplete: Busca por nome/alias autorizado;
  seleção por ID; nenhum ID digitado como autorização; off.
  Dependência/validação: Pessoa-alvo fixa em edição; trocar pessoa é outra
  ação explícita. Ajuda/exemplo: “Editar o vínculo de Ana”, sem substituir
  Bruno silenciosamente.. Erro: Revise estado do vínculo: Pessoa-alvo fixa em
  edição; trocar pessoa é outra ação explícita..

- **CTRL-114-01 — Capacidade**. SEARCHABLE_COMBOBOX. Ordem 114.1; Conforme
  ação. Máscara/autocomplete: Busca por nome/alias autorizado; seleção por ID;
  nenhum ID digitado como autorização; off. Dependência/validação: Não retirar
  proteção de último admin ou identidade do recebedor. Ajuda/exemplo: Resumo
  antes/depois e próxima autoridade.. Erro: Revise capacidade: Não retirar
  proteção de último admin ou identidade do recebedor..

- **CTRL-114-02 — Override**. SEARCHABLE_COMBOBOX. Ordem 114.2; Conforme ação.
  Máscara/autocomplete: Busca por nome/alias autorizado; seleção por ID;
  nenhum ID digitado como autorização; off. Dependência/validação: Não retirar
  proteção de último admin ou identidade do recebedor. Ajuda/exemplo: Resumo
  antes/depois e próxima autoridade.. Erro: Revise override: Não retirar
  proteção de último admin ou identidade do recebedor..

- **CTRL-116-01 — Nome curto**. TEXT_INPUT. Ordem 116.1; Não.
  Máscara/autocomplete: Sem máscara artificial; preservar texto e limite do
  contrato; off. Dependência/validação: Omitir=manter; remover=ação explícita,
  não omissão de vazio. Ajuda/exemplo: Confirmar resultado na reconsulta..
  Erro: Revise nome curto: Omitir=manter; remover=ação explícita, não omissão
  de vazio..

- **CTRL-118-01 — Motivo de revogação**. TEXTAREA. Ordem 118.1; Ao revogar.
  Máscara/autocomplete: Sem máscara; contador e limite do contrato visíveis;
  quebra de linha/reflow; off. Dependência/validação: Proposta 3–1000,
  histórico preservado. Ajuda/exemplo: Revogar agora mesmo com pendências..
  Erro: Revise motivo de revogação: Proposta 3–1000, histórico preservado..

- **CTRL-C7-001 — Situação da credencial**. RADIO_OR_SELECT. Ordem C7.1;
  Conforme etapa; leitura de servidor ou escolha explícita; sem confirmação
  material por default. Máscara/autocomplete: Conforme tipo; string decimal
  exata/data local com fuso; identificador opaco só leitura; off.
  Dependência/validação: Informado/conferido pela família/validado
  externamente; última opção só com prova externa. Ajuda/exemplo: Nenhum selo
  automático. Erro: Revise situação da credencial. Informado/conferido pela
  família/validado externamente; última opção só com prova externa.

- **CTRL-C7-002 — Quem conferiu a credencial**. READ_ONLY_DESCRIPTION. Ordem
  C7.2; Conforme etapa; leitura de servidor ou escolha explícita; sem
  confirmação material por default. Máscara/autocomplete: Conforme tipo;
  string decimal exata/data local com fuso; identificador opaco só leitura;
  off. Dependência/validação: Identidade do administrador familiar que
  realizou a conferência. Ajuda/exemplo: Servidor, não nome livre atribuído a
  terceiro. Erro: Revise quem conferiu a credencial. Identidade do
  administrador familiar que realizou a conferência.

- **CTRL-C7-003 — Data e resultado da conferência**. READ_ONLY_DESCRIPTION.
  Ordem C7.3; Conforme etapa; leitura de servidor ou escolha explícita; sem
  confirmação material por default. Máscara/autocomplete: Conforme tipo;
  string decimal exata/data local com fuso; identificador opaco só leitura;
  off. Dependência/validação: Instante/valor conferido/resultado preservados;
  dado alterado pede nova conferência. Ajuda/exemplo: Não editar histórico da
  conferência. Erro: Revise data e resultado da conferência. Instante/valor
  conferido/resultado preservados; dado alterado pede nova conferência.

- **CTRL-C7-004 — Mostrar guia no primeiro acesso**. CHECKBOX_OR_SWITCH. Ordem
  C7.4; Conforme etapa; leitura de servidor ou escolha explícita; sem
  confirmação material por default. Máscara/autocomplete: Conforme tipo;
  string decimal exata/data local com fuso; identificador opaco só leitura;
  off. Dependência/validação: Configuração por administração autorizada;
  usuário pode reabrir no perfil. Ajuda/exemplo: Escolha explícita no
  cadastro/vínculo; sem mudar permissões. Erro: Revise mostrar guia no
  primeiro acesso. Configuração por administração autorizada; usuário pode
  reabrir no perfil.

## Estado, teclado e ajuda

Herda os estados descritos no blueprint; em cada painel a falha é isolada.
Skeleton não cria ausência; erro não elimina dado válido de outra seção. Foco
vai ao primeiro inválido; sucesso anuncia efeito, Escape/Voltar restauram
acionador. Combobox usa setas/Enter/Escape e label associado. Tooltip em botão
Ajuda sobre [campo] é acessível por foco; regra necessária permanece inline.
Sem informação só por cor, hover, gesto ou QR.

Ajuda contextual: guia da tarefa e perfil, reabrível pelo perfil. Captura real
futura: `SHOT-ID-04` no mesmo SHA de D, sem dados pessoais/segredos.
Protótipo: `staff/staffAdd/staffDetails`; ausência de exemplo no HTML é
declarada, sem novo mockup equivalente. B1: SC-022, SC-023, SC-034, OVL-005,
OVL-006.

Critérios C9 relacionados: C-AC-012, C-AC-013, C-AC-014, C-AC-019, C-AC-020,
C-AC-027, C-AC-030, C-AC-031, C-AC-048, C-AC-061, C-AC-068, C-AC-069,
C-AC-070, C-AC-076, C-AC-080, C-AC-081, C-AC-082, C-AC-085, C-AC-097,
C-AC-102, C-AC-117, C-NEW-AC-007, C-NEW-AC-027, C7-AC-001, C7-AC-005,
C7-AC-007. A associação é por domínio; cada caso preserva seu discriminante
específico e não significa que todos os critérios foram executados nesta tela.
Fonte funcional:
[IDENTITY_ACCESS_MEMBERSHIPS](../../C3-functional-specification/IDENTITY_ACCESS_MEMBERSHIPS.md).
