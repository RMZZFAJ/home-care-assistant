# ID-03 — Aceitar vínculo com segurança

Estado: direção visual OWNER_APPROVED; especificação TO_BE, não implementada.

Perfil e permissão: Titular do convite. Banco/API revalidam capacidade, alvo e
versão; menu/ID/escala não concedem autorização.

Rota/superfície: /convites/aceitar, atual a alterar. Gatilho: navegar pela
tarefa ou abrir o alvo contextual autorizado. Objetivo: Prévia mínima segura e
aceite pela conta correta; cadastro pessoal e confirmação.

## Composição e sequência

Prévia mínima de paciente/papel/emissor/validade e conta atual;
cadastro/entrada/aceite em etapas claras.

Desktop: aplicar essa hierarquia no shell aprovado, tarefa primeiro e ajuda
lateral quando útil. Tablet: preservar ordem de foco e duas colunas só se
rótulos/valores couberem. Móvel: empilhar na mesma ordem; diálogo longo ocupa
largura disponível e rola internamente, footer não cobre campo/teclado;
resumo/ações continuam alcançáveis.

Token inválido não enumera paciente; já aceito abre contexto sem duplicar.

## Ações e efeito

Primária: **Aceitar este vínculo**. Secundárias: Trocar conta; Entrar; Voltar.

Consequência: Só identidade de e-mail confirmado aceita o próprio vínculo.
Mostrar objeto/quantidade/pessoa/versão antes de qualquer decisão material.
Retorno/Voltar preserva edição e contexto; próximo destino é resultado do ato
ou tarefa pertinente, nunca novo envio automático. Em resposta incerta
consultar intenção antes de prosseguir.

## Controles em ordem de tarefa

Os IDs abaixo são canônicos no catálogo de controles. Campos compostos C3
foram desdobrados; na revisão/detalhe aparecem em leitura, não novamente
editáveis. Servidor é a origem de identidade/versões/estados.

- **CTRL-105-01 — E-mail de acesso**. EMAIL_INPUT. Ordem 105.1; Sim no
  login/convite. Máscara/autocomplete: Formato e-mail; sem autocapitalização;
  email. Dependência/validação: Formato, até 254; confirmação pelo Auth para
  aceite. Ajuda/exemplo: “<pessoa.exemplo@dominio.test>”, fictício.. Erro:
  Revise e-mail de acesso: Formato, até 254; confirmação pelo Auth para
  aceite..

- **CTRL-115-01 — Validade do convite**. READ_ONLY_DESCRIPTION. Ordem 115.1;
  Sim na prévia válida. Máscara/autocomplete: SEM_MASCARA;valor do servidor;
  off. Dependência/validação: Token hash, e-mail correto, revogação e prazo no
  aceite. Ajuda/exemplo: Token inválido não revela nome do paciente.. Erro:
  Revise validade do convite: Token hash, e-mail correto, revogação e prazo no
  aceite..

- **CTRL-115-02 — Emissor do convite**. READ_ONLY_DESCRIPTION. Ordem 115.2;
  Sim na prévia válida. Máscara/autocomplete: SEM_MASCARA;valor do servidor;
  off. Dependência/validação: Token hash, e-mail correto, revogação e prazo no
  aceite. Ajuda/exemplo: Token inválido não revela nome do paciente.. Erro:
  Revise emissor do convite: Token hash, e-mail correto, revogação e prazo no
  aceite..

## Estado, teclado e ajuda

Herda os estados descritos no blueprint; em cada painel a falha é isolada.
Skeleton não cria ausência; erro não elimina dado válido de outra seção. Foco
vai ao primeiro inválido; sucesso anuncia efeito, Escape/Voltar restauram
acionador. Combobox usa setas/Enter/Escape e label associado. Tooltip em botão
Ajuda sobre [campo] é acessível por foco; regra necessária permanece inline.
Sem informação só por cor, hover, gesto ou QR.

Ajuda contextual: guia da tarefa e perfil, reabrível pelo perfil. Captura real
futura: `SHOT-ID-03` no mesmo SHA de D, sem dados pessoais/segredos.
Protótipo: `SEM_EQUIVALENTE_NO_HTML`; ausência de exemplo no HTML é declarada,
sem novo mockup equivalente. B1: SC-004, SC-023.

Critérios C9 relacionados: C-AC-012, C-AC-013, C-AC-014, C-AC-019, C-AC-020,
C-AC-027, C-AC-030, C-AC-031, C-AC-048, C-AC-061, C-AC-068, C-AC-069,
C-AC-070, C-AC-076, C-AC-080, C-AC-081, C-AC-082, C-AC-085, C-AC-097,
C-AC-102, C-AC-117, C-NEW-AC-007, C-NEW-AC-027, C7-AC-001, C7-AC-005,
C7-AC-007. A associação é por domínio; cada caso preserva seu discriminante
específico e não significa que todos os critérios foram executados nesta tela.
Fonte funcional:
[IDENTITY_ACCESS_MEMBERSHIPS](../../C3-functional-specification/IDENTITY_ACCESS_MEMBERSHIPS.md).
