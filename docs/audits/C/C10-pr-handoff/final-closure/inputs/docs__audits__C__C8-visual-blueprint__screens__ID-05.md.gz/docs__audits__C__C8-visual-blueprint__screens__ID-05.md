# ID-05 — Selecionar contexto e lidar com acesso alterado

Estado: direção visual OWNER_APPROVED; especificação TO_BE, não implementada.

Perfil e permissão: Conta com contextos autorizados. Banco/API revalidam
capacidade, alvo e versão; menu/ID/escala não concedem autorização.

Rota/superfície: Troca de contexto, atual a preservar. Gatilho: navegar pela
tarefa ou abrir o alvo contextual autorizado. Objetivo: Escolher paciente ou
modo global explicitamente e revalidar capacidades.

## Composição e sequência

Seletor de paciente/modo no cabeçalho; barreira persistente ao perder acesso,
com retorno seguro.

Desktop: aplicar essa hierarquia no shell aprovado, tarefa primeiro e ajuda
lateral quando útil. Tablet: preservar ordem de foco e duas colunas só se
rótulos/valores couberem. Móvel: empilhar na mesma ordem; diálogo longo ocupa
largura disponível e rola internamente, footer não cobre campo/teclado;
resumo/ações continuam alcançáveis.

Ação não registrada só com recusa comprovada; resposta incerta primeiro
consulta intenção.

## Ações e efeito

Primária: **Abrir contexto autorizado**. Secundárias: Entrar novamente; Buscar
ajuda; Sair.

Consequência: Somente contexto do servidor autoriza novas ações. Mostrar
objeto/quantidade/pessoa/versão antes de qualquer decisão material.
Retorno/Voltar preserva edição e contexto; próximo destino é resultado do ato
ou tarefa pertinente, nunca novo envio automático. Em resposta incerta
consultar intenção antes de prosseguir.

## Controles em ordem de tarefa

Os IDs abaixo são canônicos no catálogo de controles. Campos compostos C3
foram desdobrados; na revisão/detalhe aparecem em leitura, não novamente
editáveis. Servidor é a origem de identidade/versões/estados.

- **CTRL-C7-019 — Resultado da intenção consultada**. READ_ONLY_DESCRIPTION.
  Ordem C7.19; Conforme etapa; leitura de servidor ou escolha explícita; sem
  confirmação material por default. Máscara/autocomplete: Conforme tipo;
  string decimal exata/data local com fuso; identificador opaco só leitura;
  off. Dependência/validação: Recusa sem persistência vs confirmado vs ainda
  incerto. Ajuda/exemplo: Não afirmar ação não registrada antes da consulta
  quando resultado incerto. Erro: Revise resultado da intenção consultada.
  Recusa sem persistência vs confirmado vs ainda incerto.

## Estado, teclado e ajuda

Herda os estados descritos no blueprint; em cada painel a falha é isolada.
Skeleton não cria ausência; erro não elimina dado válido de outra seção. Foco
vai ao primeiro inválido; sucesso anuncia efeito, Escape/Voltar restauram
acionador. Combobox usa setas/Enter/Escape e label associado. Tooltip em botão
Ajuda sobre [campo] é acessível por foco; regra necessária permanece inline.
Sem informação só por cor, hover, gesto ou QR.

Ajuda contextual: guia da tarefa e perfil, reabrível pelo perfil. Captura real
futura: `SHOT-ID-05` no mesmo SHA de D, sem dados pessoais/segredos.
Protótipo: `SEM_EQUIVALENTE_NO_HTML`; ausência de exemplo no HTML é declarada,
sem novo mockup equivalente. B1: OVL-022, OVL-023.

Critérios C9 relacionados: C-AC-012, C-AC-013, C-AC-014, C-AC-019, C-AC-020,
C-AC-027, C-AC-030, C-AC-031, C-AC-048, C-AC-061, C-AC-068, C-AC-069,
C-AC-070, C-AC-076, C-AC-080, C-AC-081, C-AC-082, C-AC-085, C-AC-097,
C-AC-102, C-AC-117, C-NEW-AC-007, C-NEW-AC-027, C7-AC-001, C7-AC-005,
C7-AC-007. A associação é por domínio; cada caso preserva seu discriminante
específico e não significa que todos os critérios foram executados nesta tela.
Fonte funcional:
[IDENTITY_ACCESS_MEMBERSHIPS](../../C3-functional-specification/IDENTITY_ACCESS_MEMBERSHIPS.md).
