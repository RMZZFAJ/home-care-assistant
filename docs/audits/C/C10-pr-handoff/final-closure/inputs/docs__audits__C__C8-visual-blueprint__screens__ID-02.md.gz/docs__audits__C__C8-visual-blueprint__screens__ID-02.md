# ID-02 — Meu perfil e preferências

Estado: direção visual OWNER_APPROVED; especificação TO_BE, não implementada.

Perfil e permissão: Titular autenticado. Banco/API revalidam capacidade, alvo
e versão; menu/ID/escala não concedem autorização.

Rota/superfície: /perfil, atual a alterar. Gatilho: navegar pela tarefa ou
abrir o alvo contextual autorizado. Objetivo: Dados próprios, contatos, senha,
MFA, sessões e preferências; estado por operação.

## Composição e sequência

Seções Identidade/Contatos/Segurança/Aparelhos/Preferências/Guias; uma
ação/estado por seção.

Desktop: aplicar essa hierarquia no shell aprovado, tarefa primeiro e ajuda
lateral quando útil. Tablet: preservar ordem de foco e duas colunas só se
rótulos/valores couberem. Móvel: empilhar na mesma ordem; diálogo longo ocupa
largura disponível e rola internamente, footer não cobre campo/teclado;
resumo/ações continuam alcançáveis.

Credencial informada/conferida/externa distintas; nunca exportar OTP/senha.

## Ações e efeito

Primária: **Salvar esta seção**. Secundárias: Reabrir apresentação; Gerir
sessões; Atualizar contato.

Consequência: Mudança pessoal não altera papel local. Mostrar
objeto/quantidade/pessoa/versão antes de qualquer decisão material.
Retorno/Voltar preserva edição e contexto; próximo destino é resultado do ato
ou tarefa pertinente, nunca novo envio automático. Em resposta incerta
consultar intenção antes de prosseguir.

## Controles em ordem de tarefa

Os IDs abaixo são canônicos no catálogo de controles. Campos compostos C3
foram desdobrados; na revisão/detalhe aparecem em leitura, não novamente
editáveis. Servidor é a origem de identidade/versões/estados.

- **CTRL-106-01 — Senha atual**. PASSWORD_WITH_REVEAL. Ordem 106.1; Só
  reautenticação aplicável. Máscara/autocomplete: Sem máscara de conteúdo;
  limite em bytes; mostrar/ocultar com nome acessível; current-password.
  Dependência/validação: Nunca logar/exportar; password manager permitido.
  Ajuda/exemplo: Não preencher por administrador.. Erro: Revise senha atual:
  Nunca logar/exportar; password manager permitido..

- **CTRL-107-01 — Nova senha**. PASSWORD_WITH_REVEAL. Ordem 107.1; Só
  cadastro/troca. Máscara/autocomplete: Sem máscara de conteúdo; limite em
  bytes; mostrar/ocultar com nome acessível; new-password.
  Dependência/validação: Contrato atual: mínimo 12 caracteres e máximo 72
  bytes UTF-8; ajuda consistente. Ajuda/exemplo: Erro explica limite sem
  repetir valor.. Erro: Revise nova senha: Contrato atual: mínimo 12
  caracteres e máximo 72 bytes UTF-8; ajuda consistente..

- **CTRL-108-01 — Nome pessoal**. TEXT_INPUT. Ordem 108.1; Sim.
  Máscara/autocomplete: Nome completo; não validar identidade por string;
  name. Dependência/validação: 2–160 caracteres. Ajuda/exemplo: Pessoa
  identificável; nome não concede capacidade.. Erro: Revise nome pessoal:
  2–160 caracteres..

- **CTRL-109-01 — Função profissional**. TEXT_INPUT. Ordem 109.1; Função
  individual; registro só quando aplicável à profissão P01.
  Máscara/autocomplete: Sem máscara artificial; preservar texto e limite do
  contrato; off. Dependência/validação: Registro até 30 e categoria até 80
  atuais; rótulo informado/validado. Ajuda/exemplo: Informado, conferido pela
  família e validado externamente são estados distintos; cuidadora sem
  registro aplicável não fornece COREN fictício.. Erro: Revise função
  profissional: Registro até 30 e categoria até 80 atuais; rótulo
  informado/validado..

- **CTRL-109-02 — Registro profissional**. TEXT_INPUT. Ordem 109.2; Função
  individual; registro só quando aplicável à profissão P01.
  Máscara/autocomplete: Sem máscara artificial; preservar texto e limite do
  contrato; off. Dependência/validação: Registro até 30 e categoria até 80
  atuais; rótulo informado/validado. Ajuda/exemplo: Informado, conferido pela
  família e validado externamente são estados distintos; cuidadora sem
  registro aplicável não fornece COREN fictício.. Erro: Revise registro
  profissional: Registro até 30 e categoria até 80 atuais; rótulo
  informado/validado..

- **CTRL-110-01 — Foto/avatar**. TEXT_INPUT. Ordem 110.1; Não.
  Máscara/autocomplete: Sem máscara artificial; preservar texto e limite do
  contrato; off. Dependência/validação: Transporte/sanitização e tentativa
  recuperável. Ajuda/exemplo: Avatar não é prova de identidade legal.. Erro:
  Revise foto/avatar: Transporte/sanitização e tentativa recuperável..

- **CTRL-111-01 — Telefone**. TEL_INPUT. Ordem 111.1; Só se vincular canal.
  Máscara/autocomplete: E.164; prefixo internacional e7–15 dígitos; formato
  visual não altera valor; tel. Dependência/validação: Telefone E.164 com
  prefixo internacional e 7–15 dígitos; código de 6–8 dígitos conforme atual;
  não usar metadata. Ajuda/exemplo: A confirmação de telefone não é
  homologação SMS do sistema.. Erro: Revise telefone: Telefone E.164 com
  prefixo internacional e 7–15 dígitos; código de 6–8 dígitos conforme atual;
  não usar metadata..

- **CTRL-111-02 — Código de confirmação**. OTP_INPUT. Ordem 111.2; Só se
  vincular canal. Máscara/autocomplete: 6–8 dígitos conforme contrato Auth;
  nunca em screenshot/log; one-time-code. Dependência/validação: Telefone
  E.164 com prefixo internacional e 7–15 dígitos; código de 6–8 dígitos
  conforme atual; não usar metadata. Ajuda/exemplo: A confirmação de telefone
  não é homologação SMS do sistema.. Erro: Revise código de confirmação:
  Telefone E.164 com prefixo internacional e 7–15 dígitos; código de 6–8
  dígitos conforme atual; não usar metadata..

- **CTRL-112-01 — Novo e-mail**. EMAIL_INPUT. Ordem 112.1; Só alteração
  voluntária. Máscara/autocomplete: Formato e-mail; sem autocapitalização;
  email. Dependência/validação: Reautenticação recente, verificação oficial e
  retorno por etapa. Ajuda/exemplo: “Contato confirmado; vínculo interno ainda
  pendente” se falhar segunda etapa.. Erro: Revise novo e-mail: Reautenticação
  recente, verificação oficial e retorno por etapa..

- **CTRL-112-02 — Novo telefone**. TEL_INPUT. Ordem 112.2; Só alteração
  voluntária. Máscara/autocomplete: E.164; prefixo internacional e7–15
  dígitos; formato visual não altera valor; tel. Dependência/validação:
  Reautenticação recente, verificação oficial e retorno por etapa.
  Ajuda/exemplo: “Contato confirmado; vínculo interno ainda pendente” se
  falhar segunda etapa.. Erro: Revise novo telefone: Reautenticação recente,
  verificação oficial e retorno por etapa..

- **CTRL-117-01 — Preferências**. RADIO_OR_SELECT. Ordem 117.1; Próprio
  usuário, defaults sem opt-in implícito. Máscara/autocomplete: Opções finitas
  com rótulo humano; sem opção material preaceita; off. Dependência/validação:
  Ciência P02; push por dispositivo; canal inexistente não prometido.
  Ajuda/exemplo: Internas permanecem fonte de estado.. Erro: Revise
  preferências: Ciência P02; push por dispositivo; canal inexistente não
  prometido..

- **CTRL-119-01 — Sessão**. READ_ONLY_DESCRIPTION. Ordem 119.1; Identificação
  de sessão, sem token exposto. Máscara/autocomplete: SEM_MASCARA;valor do
  servidor; off. Dependência/validação: Encerrar outras sessões exige
  reautenticação; não encerra indevidamente a atual. Ajuda/exemplo: Mostrar
  data e descrição aproximada, sem afirmar identidade física do aparelho..
  Erro: Revise sessão: Encerrar outras sessões exige reautenticação; não
  encerra indevidamente a atual..

- **CTRL-119-02 — Descrição do aparelho**. READ_ONLY_DESCRIPTION. Ordem 119.2;
  Identificação de sessão, sem token exposto. Máscara/autocomplete:
  SEM_MASCARA;valor do servidor; off. Dependência/validação: Encerrar outras
  sessões exige reautenticação; não encerra indevidamente a atual.
  Ajuda/exemplo: Mostrar data e descrição aproximada, sem afirmar identidade
  física do aparelho.. Erro: Revise descrição do aparelho: Encerrar outras
  sessões exige reautenticação; não encerra indevidamente a atual..

- **CTRL-C7-001 — Situação da credencial**. RADIO_OR_SELECT. Ordem C7.1;
  Conforme etapa; leitura de servidor ou escolha explícita; sem confirmação
  material por default. Máscara/autocomplete: Conforme tipo; string decimal
  exata/data local com fuso; identificador opaco só leitura; off.
  Dependência/validação: Informado/conferido pela família/validado
  externamente; última opção só com prova externa. Ajuda/exemplo: Nenhum selo
  automático. Erro: Revise situação da credencial. Informado/conferido pela
  família/validado externamente; última opção só com prova externa.

## Estado, teclado e ajuda

Herda os estados descritos no blueprint; em cada painel a falha é isolada.
Skeleton não cria ausência; erro não elimina dado válido de outra seção. Foco
vai ao primeiro inválido; sucesso anuncia efeito, Escape/Voltar restauram
acionador. Combobox usa setas/Enter/Escape e label associado. Tooltip em botão
Ajuda sobre [campo] é acessível por foco; regra necessária permanece inline.
Sem informação só por cor, hover, gesto ou QR.

Ajuda contextual: guia da tarefa e perfil, reabrível pelo perfil. Captura real
futura: `SHOT-ID-02` no mesmo SHA de D, sem dados pessoais/segredos.
Protótipo: `staff/notify/onboarding`; ausência de exemplo no HTML é declarada,
sem novo mockup equivalente. B1: SC-030, SC-036, OVL-003, OVL-011, OVL-012,
OVL-024, OVL-025, OVL-026, OVL-027, OVL-028.

Critérios C9 relacionados: C-AC-012, C-AC-013, C-AC-014, C-AC-019, C-AC-020,
C-AC-027, C-AC-030, C-AC-031, C-AC-048, C-AC-061, C-AC-068, C-AC-069,
C-AC-070, C-AC-076, C-AC-080, C-AC-081, C-AC-082, C-AC-085, C-AC-097,
C-AC-102, C-AC-117, C-NEW-AC-007, C-NEW-AC-027, C7-AC-001, C7-AC-005,
C7-AC-007. A associação é por domínio; cada caso preserva seu discriminante
específico e não significa que todos os critérios foram executados nesta tela.
Fonte funcional:
[IDENTITY_ACCESS_MEMBERSHIPS](../../C3-functional-specification/IDENTITY_ACCESS_MEMBERSHIPS.md).
